<script language="javascript" type="text/javascript">
document.write (New Date());
<script language="javascript" type="text/javascript">
d=new Date();
d.setFullYear(2022);
document.write(d);
<script language="javascript" type="text/javascript">
function message()
{
alert ("Welcome to Test Website.");
<script language="javascript" type="text/javascript">
function disp_confirm()
{
var r=confirm("Press a button!")
if (r==true)
{
alert("You pressed OK!")
}
else
{
alert("You pressed Cancel!")
}
}
</script>
    <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
	 <script src="https://www.google.com"></script>
	 <script src="https://www.bing.com"></script>
    <![endif]-->  
    <script language="javascript" type="text/javascript">
var day=new Date().getDay();
 switch (day)
{
case 0:
 document.write("Today its Monday");
 break;
case 1:
 document.write("Today its Tuesday");
 break;
case 2:
 document.write("Today its Wednesday");
 break;
case 3:
 document.write("Today its Thursday");
 break;
case 4:
 document.write("Today its Friday");
 break;
case 5:
 document.write("Today its Saturday");
 break;
case 6:
 document.write("Today its Sunday");
 break;
default:
 document.write("Error in processing");
}
<input type="button" onclick="disp_confirm()" value="Display a confirm box" />
</script>
<script>
document.getElementById("demo").innerHTML = 5 + 6;
</script>
<script> 
var myVideo = document.getElementById("video1"); 

function playPause() { 
  if (myVideo.paused) 
    myVideo.play(); 
  else 
    myVideo.pause();
	}  
</script> 
<button onclick="document.getElementById('myImage').src='https://s2.gaming-cdn.com/images/products/2419/616x353/batman-arkham-knight-pc-game-steam-cover.jpg?v=1649319361'">Batman Arkham Knight</button>

<img id="myImage" src="batman arkham.gif" style="width:100px">

<button onclick="document.getElementById('myImage').src='https://images.gog-statics.com/de60559557d039d9375b617e83df1eba1bd1d04ba8dffef45f36f3a6b91f5e37.jpg'">Batman Arkham Asylum</button>
